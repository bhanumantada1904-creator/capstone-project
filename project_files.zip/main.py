
import pandas as pd
import sqlite3

def load_data():
    conn = sqlite3.connect('books (1).db')
    df = pd.read_sql_query("SELECT * FROM books", conn)
    conn.close()
    return df

def clean_data(df):
    return df.drop_duplicates().dropna()

def feature_engineering(df):
    if 'price' in df.columns:
        df['price_category'] = pd.cut(df['price'], bins=3, labels=['Low','Medium','High'])
    return df

def validate_data(df):
    assert not df.empty, "DataFrame is empty"
    print(f"Data shape: {df.shape}")

def save_data(df):
    df.to_csv('cleaned_output.csv', index=False)

def main():
    print("Pipeline Started")
    df = load_data()
    df = clean_data(df)
    df = feature_engineering(df)
    validate_data(df)
    save_data(df)
    print("Pipeline Completed!")

if __name__ == "__main__":
    main()
