def validate_data(df):
    pass